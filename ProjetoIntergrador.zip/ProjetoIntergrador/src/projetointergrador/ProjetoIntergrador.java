package projetointergrador;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class ProjetoIntergrador {

    public static void main(String[] args) {

        Scanner entrada = new Scanner(System.in);

        bannerWelcome();
        //<~ banner RPG Binary Soul()

        apresentacao();
        //<~ função Apresentação do game.

        digiteEnter();
        //<~ função Digite 1 para seguir a diante.

        clear();
        //<~ função limpar console

        miniBannerBinarySoul();
        //<~ função mini banner

        String nome = nomedeusuario();
        //<~ função Insira o nome de usurio
        //Variaveis principais do jogo, que foram utilizadas

        String A1, A2, A3, A4, A5, A6, A7, A8, A9, A10;
        String B1, B2, B3, B4, B5, B6, B7, B8, B9, B10;
        String C1, C2, C3, C4, C5, C6, C7, C8, C9, C10;
        String D1, D2, D3, D4, D5, D6, D7, D8, D9, D10;
        String E1, E2, E3, E4, E5, E6, E7, E8, E9, E10;
        String alternativaCorreta1, alternativaCorreta2;
        String alternativaCorreta3, alternativaCorreta4;
        String alternativaCorreta5, alternativaCorreta6;
        String alternativaCorreta7, alternativaCorreta8;
        String alternativaCorreta9, alternativaCorreta10;
        String questions1, questions2, questions3;
        String questions4, questions5, questions6;
        String questions7, questions8, questions9;
        String questions10;

        //=========//==========// PRIMEIRO CAPITULO //=========//==========//
        primeiroCaptulo(); // Nesta função esta armazenada o primeiro capitulo da historia.

        questions1 = "Ex: 1 + 1 "; // aqui você coloca a questão a ser resolvida

        A1 = " 2 ";  // aqui você coloca uma das alternativas
        B1 = " 4 ";  // aqui você coloca uma das alternativas
        C1 = " 6 ";  // aqui você coloca uma das alternativas
        D1 = " 8 ";  // aqui você coloca uma das alternativas
        E1 = " 10 "; // aqui você coloca uma das alternativas

        alternativaCorreta1 = " 2 "; // aqui você coloca a questão que será considerada a correta,
        //Obs. tem que esta exatamente como nas alternativas.

        desafio(A1, B1, C1, D1, E1, alternativaCorreta1, questions1); // aqui tudo é jogado para a função criada
        //Que valida, embaralha, e organiza as questões de forma altomatica.

        //=========//==========// SEGUNDO CAPITULO //=========//==========//
        segundoCaptulo();

        questions2 = ""; // aqui você coloca a questão a ser resolvida

        A2 = "  ";  // aqui você coloca uma das alternativas
        B2 = "  ";  // aqui você coloca uma das alternativas
        C2 = "  ";  // aqui você coloca uma das alternativas
        D2 = "  ";  // aqui você coloca uma das alternativas
        E2 = "  ";  // aqui você coloca uma das alternativas

        alternativaCorreta2 = "  "; // aqui você coloca a questão que será considerada a correta,
        //Obs. tem que esta exatamente como nas alternativas.

        desafio(A2, B2, C2, D2, E2, alternativaCorreta2, questions2); // aqui tudo é jogado para a função criada
        //Que valida, embaralha, e organiza as questões de forma altomatica.

        //=========//==========// TERCEIRO CAPITULO //=========//==========//
        terceiroCaptulo();

        questions3 = ""; // aqui você coloca a questão a ser resolvida

        A3 = "  ";  // aqui você coloca uma das alternativas
        B3 = "  ";  // aqui você coloca uma das alternativas
        C3 = "  ";  // aqui você coloca uma das alternativas
        D3 = "  ";   // aqui você coloca uma das alternativas
        E3 = "  "; // aqui você coloca uma das alternativas

        alternativaCorreta3 = "  "; // aqui você coloca a questão que será considerada a correta,
        //Obs. tem que esta exatamente como nas alternativas.

        desafio(A3, B3, C3, D3, E3, alternativaCorreta3, questions3); // aqui tudo é jogado para a função criada
        //Que valida, embaralha, e organiza as questões de forma altomatica.

        //=========//==========// QUARTO CAPITULO //=========//==========//
        quartoCaptulo();

        questions4 = ""; // aqui você coloca a questão a ser resolvida

        A4 = "  ";  // aqui você coloca uma das alternativas
        B4 = "  ";  // aqui você coloca uma das alternativas
        C4 = "  ";  // aqui você coloca uma das alternativas
        D4 = "  ";   // aqui você coloca uma das alternativas
        E4 = "  "; // aqui você coloca uma das alternativas

        alternativaCorreta4 = "  "; // aqui você coloca a questão que será considerada a correta,
        //Obs. tem que esta exatamente como nas alternativas.

        desafio(A4, B4, C4, D4, E4, alternativaCorreta4, questions4); // aqui tudo é jogado para a função criada
        //Que valida, embaralha, e organiza as questões de forma altomatica.

        //=========//==========// QUINTO CAPITULO //=========//==========//
        quintoCaptulo();

        questions5 = ""; // aqui você coloca a questão a ser resolvida

        A5 = "  ";  // aqui você coloca uma das alternativas
        B5 = "  ";  // aqui você coloca uma das alternativas
        C5 = "  ";  // aqui você coloca uma das alternativas
        D5 = "  ";   // aqui você coloca uma das alternativas
        E5 = "  "; // aqui você coloca uma das alternativas

        alternativaCorreta5 = "  "; // aqui você coloca a questão que será considerada a correta,
        //Obs. tem que esta exatamente como nas alternativas.

        desafio(A5, B5, C5, D5, E5, alternativaCorreta5, questions5); // aqui tudo é jogado para a função criada
        //Que valida, embaralha, e organiza as questões de forma altomatica.

        //=========//==========// SEXTO CAPITULO //=========//==========//
        sextoCaptulo();

        questions6 = ""; // aqui você coloca a questão a ser resolvida

        A6 = "  ";  // aqui você coloca uma das alternativas
        B6 = "  ";  // aqui você coloca uma das alternativas
        C6 = "  ";  // aqui você coloca uma das alternativas
        D6 = "  ";   // aqui você coloca uma das alternativas
        E6 = "  "; // aqui você coloca uma das alternativas

        alternativaCorreta6 = "  "; // aqui você coloca a questão que será considerada a correta,
        //Obs. tem que esta exatamente como nas alternativas.

        desafio(A6, B6, C6, D6, E6, alternativaCorreta6, questions6); // aqui tudo é jogado para a função criada
        //Que valida, embaralha, e organiza as questões de forma altomatica.

        //=========//==========// SÉTIMO CAPITULO //=========//==========//
        setimoCaptulo();

        questions7 = ""; // aqui você coloca a questão a ser resolvida

        A7 = "  ";  // aqui você coloca uma das alternativas
        B7 = "  ";  // aqui você coloca uma das alternativas
        C7 = "  ";  // aqui você coloca uma das alternativas
        D7 = "  ";   // aqui você coloca uma das alternativas
        E7 = "  "; // aqui você coloca uma das alternativas

        alternativaCorreta7 = "  "; // aqui você coloca a questão que será considerada a correta,
        //Obs. tem que esta exatamente como nas alternativas.

        desafio(A7, B7, C7, D7, E7, alternativaCorreta7, questions7); // aqui tudo é jogado para a função criada
        //Que valida, embaralha, e organiza as questões de forma altomatica.

        //=========//==========// OITAVO CAPITULO //=========//==========//
        oitavoCaptulo();

        questions8 = ""; // aqui você coloca a questão a ser resolvida

        A8 = "  ";  // aqui você coloca uma das alternativas
        B8 = "  ";  // aqui você coloca uma das alternativas
        C8 = "  ";  // aqui você coloca uma das alternativas
        D8 = "  ";   // aqui você coloca uma das alternativas
        E8 = "  "; // aqui você coloca uma das alternativas

        alternativaCorreta8 = "  "; // aqui você coloca a questão que será considerada a correta,
        //Obs. tem que esta exatamente como nas alternativas.

        desafio(A8, B8, C8, D8, E8, alternativaCorreta8, questions8); // aqui tudo é jogado para a função criada
        //Que valida, embaralha, e organiza as questões de forma altomatica.

        //=========//==========// NONO CAPITULO //=========//==========//
        nonoCaptulo();

        questions9 = ""; // aqui você coloca a questão a ser resolvida

        A9 = "  ";  // aqui você coloca uma das alternativas
        B9 = "  ";  // aqui você coloca uma das alternativas
        C9 = "  ";  // aqui você coloca uma das alternativas
        D9 = "  ";   // aqui você coloca uma das alternativas
        E9 = "  "; // aqui você coloca uma das alternativas

        alternativaCorreta9 = "  "; // aqui você coloca a questão que será considerada a correta,
        //Obs. tem que esta exatamente como nas alternativas.

        desafio(A9, B9, C9, D9, E9, alternativaCorreta9, questions9); // aqui tudo é jogado para a função criada
        //Que valida, embaralha, e organiza as questões de forma altomatica.

        //=========//==========// DECIMO CAPITULO //=========//==========//
        decimoCaptulo();

        questions10 = ""; // aqui você coloca a questão a ser resolvida

        A10 = "  ";  // aqui você coloca uma das alternativas
        B10 = "  ";  // aqui você coloca uma das alternativas
        C10 = "  ";  // aqui você coloca uma das alternativas
        D10 = "  ";   // aqui você coloca uma das alternativas
        E10 = "  "; // aqui você coloca uma das alternativas

        alternativaCorreta10 = "  "; // aqui você coloca a questão que será considerada a correta,
        //Obs. tem que esta exatamente como nas alternativas.

        desafio(A10, B10, C10, D10, E10, alternativaCorreta10, questions10); // aqui tudo é jogado para a função criada
        //Que valida, embaralha, e organiza as questões de forma altomatica.

        //=========//==========//================//=========//==========//
    } // Metodo que chama todas as outras funçoes,

    static String nomedeusuario() {
        Scanner entrada = new Scanner(System.in);
        String nickName;
        boolean YesOrNotResult;

        do {
            System.out.println("");
            System.out.println("\n\n\n\n");
            System.out.println("  ###      ###      ###      ###      ###      ###      ###         ");
            System.out.println(" #####    #####    #####    #####    #####    #####    #####        ");
            System.out.println("#  #  #  #  #  #  #  #  #  #  #  #  #  #  #  #  #  #  #  #  #       ");
            System.out.println("#######  #######  #######  #######  #######  #######  #######       ");
            System.out.println("# # # #  # # # #  # # # #  # # # #  # # # #  # # # #  # # # #        ");
            System.out.println("\n\n\n\n");

            System.out.println("");
            System.out.println("");
            System.out.println("");
            System.out.println("=================================================");
            System.out.println("                                                 ");
            System.out.println("          Insira seu como gostaria de            ");
            System.out.println("                ser chamado                      ");
            System.out.println("                                                 ");
            System.out.println("=================================================");
            System.out.println();
            System.out.println();
            System.out.println();

            System.out.print(" => ");
            nickName = entrada.next();

            String perguntaNome = ("Gostaruia de se chamar '" + nickName + "' ? \n Responda ( Sim ou Nao )");
            YesOrNotResult = YesOrNot(perguntaNome);

        } while (YesOrNotResult == false);

        System.out.println("Seu nome será '" + nickName + "' durante o jogo!!! ");

        return nickName;

    } // Função de inserção do nome de usuario, que retorna o valor "nomeDeUsuario para a classe main"

    private static void bannerWelcome() {
        System.out.print(""
                + "           ...''',,,,,,'''...                      ...''',,,,,,'''...           \n"
                + "        ..',,,,,,,,,,,,,,,,,,'...               ..',,,,,,,,,,,,,,,,,,'...       \n"
                + "     ..',,,,,,,,,,,,,,,,,,,,,,,,'..          ..',,,,,,,,,,,,,,,,,,,,,,,,'..     \n"
                + "    .',,,,,,,,,,,,,,,,,,,,,,,,,,,,'.        .',,,,,,,,,,,,,,,,,,,,,,,,,,,,'.    \n"
                + "  ..,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,'.    ..,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,'.  \n"
                + " .',,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,'.  .',,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,'. \n"
                + " .,,,,,,,,'.....',,,,,,'.....',,,,,,,,.  .,,,,,,,,'.....',,,,,,'.....',,,,,,,,. \n"
                + ".',,,,,,,'.     .,,,,,,.     .',,,,,,,'..',,,,,,,'.     .,,,,,,.     .',,,,,,,'.\n"
                + ".,,,,,,,,'.     .',,,,'.     .',,,,,,,,..,,,,,,,,'.     .',,,,'.     .',,,,,,,,.\n"
                + ".,,,,,,,,'.     .,,,,,,.     .',,,,,,,,..,,,,,,,,'.     .,,,,,,.     .',,,,,,,,.\n"
                + ".,,,,,,,,,'.....,,,,,,,,.....',,,,,,,,,..,,,,,,,,,'.....,,,,,,,,.....',,,,,,,,,.\n"
                + ".,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,..,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,.\n"
                + ".,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,..,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,.\n"
                + ".,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,..,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,.\n"
                + ".,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,..,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,.\n"
                + ".,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,..,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,.\n"
                + ".,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,..,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,.\n"
                + ".,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,..,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,.\n"
                + "..',,,,'...',,,,,'....',,,,,'...',,,,'. ..',,,,'...',,,,,'....',,,,,'...',,,,'. \n"
                + "  .',,'.    .','..    ..','.    ..,,'.  .',,'.    .','..    ..','.    ..,,'.      ");
        System.out.println("Ol\u00e1 mund\u00e3o velho!");
        System.out.println(""
                + "                                                                     \n"
                + "                     ######  ######   #####                          \n"
                + "                     #     # #     # #     #                         \n"
                + "                     #     # #     # #                               \n"
                + "                     ######  ######  #  ####                         \n"
                + "                     #   #   #       #     #                         \n"
                + "                     #    #  #       #     #                         \n"
                + "                     #     # #        #####                          \n"
                + "                    _________________________                        \n"
                + "######                                   #####                       \n"
                + "#     # # #    #   ##   #####  #   #    #     #  ####  #    # #      \n"
                + "#     # # ##   #  #  #  #    #  # #     #       #    # #    # #      \n"
                + "######  # # #  # #    # #    #   #       #####  #    # #    # #      \n"
                + "#     # # #  # # ###### #####    #            # #    # #    # #      \n"
                + "#     # # #   ## #    # #   #    #      #     # #    # #    # #      \n"
                + "######  # #    # #    # #    #   #       #####   ####   ####  ###### \n"
                + "_____________________________________________________________________\n"
                + " \n"
        );

    } // Função que cria o banner na tela de inicio

    private static void apresentacao() {

        System.out.println("Bem vindo ao Binay Soul,\n"
                + "\n "
                + "Neste jogo funcionará com uma dinâmica de interpretação de "
                + "papéis,\n ou seja, você será um(a) jovem garoto(a), que entrará "
                + "em uma aventura,\n passando por muitos desafios e com isso"
                + "aprenderá mais sobre os conceitos de números binários. \n "
                + "A história se passa em um mundo distante e sombrio, jamais visitado novamente,\n"
                + "pois todos que passaram por lá, tiveram suas vidas roubadas \n"
                + "e nunca mais retornaram.\n Para sobreviver a esse mundo, você terá"
                + "que combater as criaturas\n que apareceram no seu caminho antes que"
                + "elas matem você.\n Será que você conseguirá sair desse jogo vivo"
                + "e ganhar a recompensa final?\n\n Eai, pronto para entrar nessa aventura?");
        System.out.println("                                                 ");
        System.out.println("====================================================");
    } // Breve introdução no inicio do jogo

    private static void digiteEnter() {
        Scanner entrada = new Scanner(System.in);

        System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
        System.out.println("  ");
        System.out.println("  Pressione 'Enter' para continuar. ");
        System.out.println("  ");
        System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
        System.out.println(" ");
        System.out.println("");

        System.out.print("~> ");
        entrada.nextLine();

    } // Função que pede que digite enter para continuar

    private static void clear() {
        System.out.println("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n "
                + "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n"
                + "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");

    } //Função limpa o console, com divesos espaços

    private static void bannerCapitulo01() {
        System.out.println("");
        System.out.println("");
        System.out.println("");
        System.out.println("");

        System.out.println(""
                + "#######                           #####                                           \n"
                + "#       # #####   ####  #####    #     # #    #   ##   #####  ##### ###### #####  \n"
                + "#       # #    # #        #      #       #    #  #  #  #    #   #   #      #    # \n"
                + "#####   # #    #  ####    #      #       ###### #    # #    #   #   #####  #    # \n"
                + "#       # #####       #   #      #       #    # ###### #####    #   #      #####  \n"
                + "#       # #   #  #    #   #      #     # #    # #    # #        #   #      #   #  \n"
                + "#       # #    #  ####    #       #####  #    # #    # #        #   ###### #    # \n"
                + "\n\n\n\n\n\n\n\n\n\n\n\n\n\n");

        System.out.println("");
        System.out.println("");
        System.out.println("");
        System.out.println("");

    } //Banner de inicio do capitulo

    private static void bannerCapitulo02() {
        System.out.println("");
        System.out.println("");
        System.out.println("");
        System.out.println("");

        System.out.println(""
                + " #####                                                #####                                           \n"
                + "#     # ######  ####  #    # #    # #####   ####     #     # #    #   ##   #####  ##### ###### #####  \n"
                + "#       #      #    # #    # ##   # #    # #    #    #       #    #  #  #  #    #   #   #      #    # \n"
                + " #####  #####  #      #    # # #  # #    # #    #    #       ###### #    # #    #   #   #####  #    # \n"
                + "      # #      #  ### #    # #  # # #    # #    #    #       #    # ###### #####    #   #      #####  \n"
                + "#     # #      #    # #    # #   ## #    # #    #    #     # #    # #    # #        #   #      #   #  \n"
                + " #####  ######  ####   ####  #    # #####   ####      #####  #    # #    # #        #   ###### #    # \n"
                + "\n\n\n\n\n\n\n\n\n\n\n\n\n\n");

        System.out.println("");
        System.out.println("");
        System.out.println("");
        System.out.println("");

    } //Banner de inicio do capitulo

    private static void bannerCapitulo03() {
        System.out.println("");
        System.out.println("");
        System.out.println("");
        System.out.println("");

        System.out.println(""
                + "#######                            #####                                           \n"
                + "   #    #    # # #####  #####     #     # #    #   ##   #####  ##### ###### #####  \n"
                + "   #    #    # # #    # #    #    #       #    #  #  #  #    #   #   #      #    # \n"
                + "   #    ###### # #    # #    #    #       ###### #    # #    #   #   #####  #    # \n"
                + "   #    #    # # #####  #    #    #       #    # ###### #####    #   #      #####  \n"
                + "   #    #    # # #   #  #    #    #     # #    # #    # #        #   #      #   #  \n"
                + "   #    #    # # #    # #####      #####  #    # #    # #        #   ###### #    # \n"
                + "\n\n\n\n\n\n\n\n\n\n\n\n\n\n");

        System.out.println("");
        System.out.println("");
        System.out.println("");
        System.out.println("");

    } //Banner de inicio do capitulo

    private static void bannerCapitulo04() {
        System.out.println("");
        System.out.println("");
        System.out.println("");
        System.out.println("");

        System.out.println(""
                + "#######                                       #####                                           \n"
                + "#        ####  #    # #####  ##### #    #    #     # #    #   ##   #####  ##### ###### #####  \n"
                + "#       #    # #    # #    #   #   #    #    #       #    #  #  #  #    #   #   #      #    # \n"
                + "#####   #    # #    # #    #   #   ######    #       ###### #    # #    #   #   #####  #    # \n"
                + "#       #    # #    # #####    #   #    #    #       #    # ###### #####    #   #      #####  \n"
                + "#       #    # #    # #   #    #   #    #    #     # #    # #    # #        #   #      #   #  \n"
                + "#        ####   ####  #    #   #   #    #     #####  #    # #    # #        #   ###### #    # "
                + "\n\n\n\n\n\n\n\n\n\n\n\n\n\n");

        System.out.println("");
        System.out.println("");
        System.out.println("");
        System.out.println("");

    } //Banner de inicio do capitulo

    private static void bannerCapitulo05() {
        System.out.println("");
        System.out.println("");
        System.out.println("");
        System.out.println("");

        System.out.println(" "
                + "#######                           #####                                           \n"
                + "#       # ###### ##### #    #    #     # #    #   ##   #####  ##### ###### #####  \n"
                + "#       # #        #   #    #    #       #    #  #  #  #    #   #   #      #    # \n"
                + "#####   # #####    #   ######    #       ###### #    # #    #   #   #####  #    # \n"
                + "#       # #        #   #    #    #       #    # ###### #####    #   #      #####  \n"
                + "#       # #        #   #    #    #     # #    # #    # #        #   #      #   #  \n"
                + "#       # #        #   #    #     #####  #    # #    # #        #   ###### #    # \n"
                + "\n\n\n\n\n\n\n\n\n\n\n\n\n\n");

        System.out.println("");
        System.out.println("");
        System.out.println("");
        System.out.println("");

    } //Banner de inicio do capitulo

    private static void bannerCapitulo06() {
        System.out.println("");
        System.out.println("");
        System.out.println("");
        System.out.println("");

        System.out.println(""
                + " #####                            #####                                           \n"
                + "#     # # #    # ##### #    #    #     # #    #   ##   #####  ##### ###### #####  \n"
                + "#       #  #  #    #   #    #    #       #    #  #  #  #    #   #   #      #    # \n"
                + " #####  #   ##     #   ######    #       ###### #    # #    #   #   #####  #    # \n"
                + "      # #   ##     #   #    #    #       #    # ###### #####    #   #      #####  \n"
                + "#     # #  #  #    #   #    #    #     # #    # #    # #        #   #      #   #  \n"
                + " #####  # #    #   #   #    #     #####  #    # #    # #        #   ###### #    # \n"
                + "\n\n\n\n\n\n\n\n\n\n\n\n\n\n");

        System.out.println("");
        System.out.println("");
        System.out.println("");
        System.out.println("");

    } //Banner de inicio do capitulo

    private static void bannerCapitulo07() {
        System.out.println("");
        System.out.println("");
        System.out.println("");
        System.out.println("");

        System.out.println(" "
                + " #####                                               #####                                           \n"
                + "#     # ###### #    # ###### #    # ##### #    #    #     # #    #   ##   #####  ##### ###### #####  \n"
                + "#       #      #    # #      ##   #   #   #    #    #       #    #  #  #  #    #   #   #      #    # \n"
                + " #####  #####  #    # #####  # #  #   #   ######    #       ###### #    # #    #   #   #####  #    # \n"
                + "      # #      #    # #      #  # #   #   #    #    #       #    # ###### #####    #   #      #####  \n"
                + "#     # #       #  #  #      #   ##   #   #    #    #     # #    # #    # #        #   #      #   #  \n"
                + " #####  ######   ##   ###### #    #   #   #    #     #####  #    # #    # #        #   ###### #    # \n");

        System.out.println("");
        System.out.println("");
        System.out.println("");
        System.out.println("");

    } //Banner de inicio do capitulo

    private static void bannerCapitulo08() {
        System.out.println("");
        System.out.println("");
        System.out.println("");
        System.out.println("");

        System.out.println(""
                + "#######                                  #####                                           \n"
                + "#       #  ####  #    # ##### #    #    #     # #    #   ##   #####  ##### ###### #####  \n"
                + "#       # #    # #    #   #   #    #    #       #    #  #  #  #    #   #   #      #    # \n"
                + "#####   # #      ######   #   ######    #       ###### #    # #    #   #   #####  #    # \n"
                + "#       # #  ### #    #   #   #    #    #       #    # ###### #####    #   #      #####  \n"
                + "#       # #    # #    #   #   #    #    #     # #    # #    # #        #   #      #   #  \n"
                + "####### #  ####  #    #   #   #    #     #####  #    # #    # #        #   ###### #    # \n"
                + "\n\n\n\n\n\n\n\n\n\n\n\n\n\n");

        System.out.println("");
        System.out.println("");
        System.out.println("");
        System.out.println("");

    } //Banner de inicio do capitulo

    private static void bannerCapitulo09() {
        System.out.println("");
        System.out.println("");
        System.out.println("");
        System.out.println("");

        System.out.println(""
                + "#     #                           #####                                           \n"
                + "##    # # #    # ##### #    #    #     # #    #   ##   #####  ##### ###### #####  \n"
                + "# #   # # ##   #   #   #    #    #       #    #  #  #  #    #   #   #      #    # \n"
                + "#  #  # # # #  #   #   ######    #       ###### #    # #    #   #   #####  #    # \n"
                + "#   # # # #  # #   #   #    #    #       #    # ###### #####    #   #      #####  \n"
                + "#    ## # #   ##   #   #    #    #     # #    # #    # #        #   #      #   #  \n"
                + "#     # # #    #   #   #    #     #####  #    # #    # #        #   ###### #    # \n"
                + "\n\n\n\n\n\n\n\n\n\n\n\n\n\n");

        System.out.println("");
        System.out.println("");
        System.out.println("");
        System.out.println("");

    } //Banner de inicio do capitulo

    private static void bannerCapitulo10() {
        System.out.println("");
        System.out.println("");
        System.out.println("");
        System.out.println("");

        System.out.println(""
                + "#######                                #####                                           \n"
                + "   #    ###### #    # ##### #    #    #     # #    #   ##   #####  ##### ###### #####  \n"
                + "   #    #      ##   #   #   #    #    #       #    #  #  #  #    #   #   #      #    # \n"
                + "   #    #####  # #  #   #   ######    #       ###### #    # #    #   #   #####  #    # \n"
                + "   #    #      #  # #   #   #    #    #       #    # ###### #####    #   #      #####  \n"
                + "   #    #      #   ##   #   #    #    #     # #    # #    # #        #   #      #   #  \n"
                + "   #    ###### #    #   #   #    #     #####  #    # #    # #        #   ###### #    # \n"
                + "\n\n\n\n\n\n\n\n\n\n\n\n\n\n");

        System.out.println("");
        System.out.println("");
        System.out.println("");
        System.out.println("");

    } //Banner de inicio do capitulo

    private static void miniBannerBinarySoul() {
        System.out.println("  ###      ###      ###      ###      ###      ###      ###         ");
        System.out.println(" #####    #####    #####    #####    #####    #####    #####        ");
        System.out.println("#  #  #  #  #  #  #  #  #  #  #  #  #  #  #  #  #  #  #  #  #       ");
        System.out.println("#######  #######  #######  #######  #######  #######  #######       ");
        System.out.println("# # # #  # # # #  # # # #  # # # #  # # # #  # # # #  # # # #        ");
        System.out.println("");
        System.out.println("");
        System.out.println("");
        System.out.println(""
                + " ####### ####### ######## ####### ####### ####### ####### \n"
                + ""
                + "      ######                               \n"
                + "      #     # # #    #   ##   #####  #   # \n"
                + "      #     # # ##   #  #  #  #    #  # #  \n"
                + "      ######  # # #  # #    # #    #   #   \n"
                + "      #     # # #  # # ###### #####    #   \n"
                + "      #     # # #   ## #    # #   #    #   \n"
                + "      ######  # #    # #    # #    #   #   \n"
                + "                                           \n"
                + "          #####                       \n"
                + "         #     #  ####  #    # #      \n"
                + "         #       #    # #    # #      \n"
                + "          #####  #    # #    # #      \n"
                + "               # #    # #    # #      \n"
                + "         #     # #    # #    # #      \n"
                + "          #####   ####   ####  ###### \n"
                + "                                      \n"
                + "                                                                                                \n"
                + " ####### ####### ######## ####### ####### ####### ####### ");
        System.out.println("\n\n\n\n\n");
    }  // mini Banner BinarySoul

    private static boolean YesOrNot(String perguntaNome) {
        Scanner entrada = new Scanner(System.in);
        boolean yesOrNotResult = false;
        String yesOrNot = "";

        for (int i = 1; i == 1; i--) {

            System.out.println(perguntaNome);
            yesOrNot = entrada.next();

            switch (yesOrNot) {

                case "sim":
                    yesOrNotResult = true;
                    break;

                case "Sim":
                    yesOrNotResult = true;
                    break;

                case "não":
                    yesOrNotResult = false;
                    break;

                case "nao":
                    yesOrNotResult = false;
                    break;

                case "Nao":
                    yesOrNotResult = false;
                    break;

                case "Não":
                    yesOrNotResult = false;
                    break;

                default:
                    i++;
                    System.out.println(" opção invalida Digie ( Sim ou Nao )");
                    break;
            }

        }

        return yesOrNotResult;

    } // Função que pergunta sim ou não e retorna true ou false para classe main

    private static void primeiroCaptulo() {

        clear();
        bannerCapitulo01();
        digiteEnter();

        // [  AQUI VAI A PRIMEIRA PARTE DA HISTÓRIA  ]
    } // Função que chama a historia do primeiro capitulo

    private static void segundoCaptulo() {
//   [  AQUI VAI A SEGUNDA PARTE DA HISTÓRIA  ]
        bannerCapitulo02();
    }  // Função que chama a historia do primeiro capitulo

    private static void terceiroCaptulo() {
//   [  AQUI VAI A TERCEIRA PARTE DA HISTÓRIA  ]
        bannerCapitulo03();

    } // Função que chama a historia do primeiro capitulo

    private static void quartoCaptulo() {
//   [  AQUI VAI A QUARTA PARTE DA HISTÓRIA  ]
        bannerCapitulo04();

    } // Função que chama a historia do primeiro capitulo

    private static void quintoCaptulo() {
//   [  AQUI VAI A QUINTA PARTE DA HISTÓRIA  ]
        bannerCapitulo05();

    } // Função que chama a historia do primeiro capitulo

    private static void sextoCaptulo() {
//   [  AQUI VAI A SEXTA PARTE DA HISTÓRIA  ]
        bannerCapitulo06();

    } // Função que chama a historia do primeiro capitulo

    private static void setimoCaptulo() {
//   [  AQUI VAI A SETIMA PARTE DA HISTÓRIA  ]
        bannerCapitulo07();

    } // Função que chama a historia do primeiro capitulo

    private static void oitavoCaptulo() {
//   [  AQUI VAI A OITAVA PARTE DA HISTÓRIA  ]
        bannerCapitulo08();

    } // Função que chama a historia do primeiro capitulo

    private static void nonoCaptulo() {
//   [  AQUI VAI A PRIMEIRA PARTE DA HISTÓRIA  ]
        bannerCapitulo09();

    } // Função que chama a historia do primeiro capitulo

    private static void decimoCaptulo() {
//   [  AQUI VAI A DECIMO PARTE DA HISTÓRIA  ]
        bannerCapitulo10();

    } // Função que chama a historia do primeiro capitulo

    private static String desafio(String a1, String b2, String c3, String d4, String e5, String alternativaCorreta1, String questions1) {
        Scanner input = new Scanner(System.in);
        int repeat = 0;
        int extra = 3;

        do {

            System.out.println("================================================");
            System.out.println("");
            System.out.println(questions1);
            System.out.println("");
            System.out.println("================================================");

            ArrayList<String> mistureba = new ArrayList<>();

            mistureba.add(a1);
            mistureba.add(b2);
            mistureba.add(c3);
            mistureba.add(d4);
            mistureba.add(e5);

            Collections.shuffle(mistureba);

            System.out.println("( A )" + mistureba.get(0));
            System.out.println("( B )" + mistureba.get(1));
            System.out.println("( C )" + mistureba.get(2));
            System.out.println("( D )" + mistureba.get(3));
            System.out.println("( E )" + mistureba.get(4));

            String nv_a = mistureba.get(0);
            String nv_b = mistureba.get(1);
            String nv_c = mistureba.get(2);
            String nv_d = mistureba.get(3);
            String nv_e = mistureba.get(4);

            System.out.println("Escolha uma das alternativas que apreseta a resposta correta");

            String cResp = alternativaCorreta1;

            String alternativa = input.next();

            switch (alternativa) {
                case "a":

                    if (nv_a.equals(cResp)) {
                        System.out.println("ALTERNATIVA CORRETA !!");
                        System.out.println(" acertou na tentativa " + extra);
                        repeat = 50;
                    } else {
                        System.out.println("ALTERNATIVA INCORRETA");
                        extra -= 1;
                        System.out.println(" Restam " + extra + " vidas ");
                    }
                    break;

                case "A":
                    if (nv_a.equals(cResp)) {
                        System.out.println("ALTERNATIVA CORRETA !!");
                        System.out.println(" acertou na tentativa " + extra);
                        repeat = 50;
                    } else {
                        System.out.println("ALTERNATIVA INCORRETA");
                        extra -= 1;
                        System.out.println(" Restam " + extra + " vidas ");
                    }

                    break;

                case "b":
                    if (nv_b.equals(cResp)) {
                        System.out.println("ALTERNATIVA CORRETA !!");
                        System.out.println(" acertou na tentativa " + extra);
                        repeat = 50;

                    } else {
                        System.out.println("ALTERNATIVA INCORRETA");
                        extra -= 1;
                        System.out.println(" Restam " + extra + " vidas ");
                    }
                    break;

                case "B":
                    if (nv_b.equals(cResp)) {
                        System.out.println("ALTERNATIVA CORRETA !!");
                        System.out.println(" acertou na tentativa " + extra);
                        repeat = 50;
                    } else {
                        System.out.println("ALTERNATIVA INCORRETA");
                        extra -= 1;
                        System.out.println(" Restam " + extra + " vidas ");
                    }
                    break;

                case "c":
                    if (nv_c.equals(cResp)) {
                        System.out.println("ALTERNATIVA CORRETA !!");
                        System.out.println(" acertou na tentativa " + extra);
                        repeat = 50;
                    } else {
                        System.out.println("ALTERNATIVA INCORRETA");
                        extra -= 1;
                        System.out.println(" Restam " + extra + " vidas ");
                    }
                    break;

                case "C":
                    if (nv_c.equals(cResp)) {
                        System.out.println("ALTERNATIVA CORRETA !!");
                        System.out.println(" acertou na tentativa " + extra);
                        repeat = 50;
                    } else {
                        System.out.println("ALTERNATIVA INCORRETA");
                        extra -= 1;
                        System.out.println(" Restam " + extra + " tentativas ");
                    }
                    break;

                case "d":
                    if (nv_d.equals(cResp)) {
                        System.out.println("ALTERNATIVA CORRETA !!");
                        System.out.println(" acertou na tentativa " + extra);
                        repeat = 50;
                    } else {
                        System.out.println("ALTERNATIVA INCORRETA");
                        extra -= 1;
                        System.out.println(" Restam " + extra + " tentativas ");
                    }
                    break;

                case "D":
                    if (nv_d.equals(cResp)) {
                        System.out.println("ALTERNATIVA CORRETA !!");
                        System.out.println(" acertou na tentativa " + extra);
                        repeat = 50;
                    } else {
                        System.out.println("ALTERNATIVA INCORRETA");
                        extra -= 1;
                        System.out.println(" Restam " + extra + " tentativas ");
                    }
                    break;

                case "e":
                    if (nv_e.equals(cResp)) {
                        System.out.println("ALTERNATIVA CORRETA !!");
                        System.out.println(" acertou na tentativa " + extra);
                        repeat = 50;
                    } else {
                        System.out.println("ALTERNATIVA INCORRETA");
                        extra -= 1;
                        System.out.println(" Restam " + extra + " tentativas ");
                    }
                    break;

                case "E":
                    if (nv_e.equals(cResp)) {
                        System.out.println("ALTERNATIVA CORRETA !!");
                        System.out.println(" acertou na tentativa " + extra);
                        repeat = 50;
                    } else {
                        System.out.println("ALTERNATIVA INCORRETA");
                        extra -= 1;
                        System.out.println(" Restam " + extra + " tentativas ");
                    }
                    break;

                default:
                    System.out.println("TENTE NOVAMENTE");
            }

            if (extra == 0) {
                System.out.println("Perdeu todas as vidas, Fame Over");
                repeat = 50;
            }
            System.out.println(" ==============================================");
        } while (repeat != 50);

        return null;
    } //Função principal que traz a aleatoriedade nas quantões, e faz a validação da opção inserida, atravez de parametros passados na main

}

/*        
               COLORINDO TEXTO

        String CSI = "\u001B[";
        System.out.print (CSI + "31" + "m");
        System.out.print ("Texto vermelho");
        System.out.println (CSI + "m");
        
        System.out.print (CSI + "32" + "m");
        System.out.print ("Texto verde");
        System.out.println (CSI + "m");
        
        System.out.print (CSI + "33" + "m");
        System.out.print ("Texto amarelo");
        System.out.println (CSI + "m");
        
        System.out.print (CSI + "39" + "m");
        System.out.print ("Texto normal");
        System.out.println (CSI + "m");*/
